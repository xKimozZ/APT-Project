package com.jetbrains.marco.photoz.clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotozCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
