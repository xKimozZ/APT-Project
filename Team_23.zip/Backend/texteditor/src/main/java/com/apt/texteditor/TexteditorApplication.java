package com.apt.texteditor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TexteditorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TexteditorApplication.class, args);
	}

}
