package com.apt.texteditor.model;

public class Operation {

    private String insert;

    public String getInsert() {
        return insert;
    }

    public void setInsert(String insert) {
        this.insert = insert;
    }
}