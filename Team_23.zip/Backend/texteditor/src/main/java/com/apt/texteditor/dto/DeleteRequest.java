package com.apt.texteditor.dto;

public class DeleteRequest {
    private String fileId;

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getFileId() {
        return fileId;
    }
}
