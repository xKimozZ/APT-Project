package com.apt.texteditor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TexteditorApplicationTests {

	@Test
	void contextLoads() {
	}

}
